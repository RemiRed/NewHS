﻿
namespace Assets.Scripts.StateManagement
{
    class GameOver : IStateBase
    {
        public void BeginState()
        {
          
        }

        public void DestroyState()
        {
            
        }

        public void OnSceneLoaded()
        {
           
        }

        public void UpdateState()
        {
           
        }

        public string GetName()
        {
            return "GameOver";
        }
    }
}
